package org.cinemaX;

public class Auditorium {
    private boolean[] seats = new boolean[32];

    public Auditorium(boolean[] seats) {
        this.seats = seats;
    }

    public boolean[] getSeats() {
        return seats;
    }

    public void setSeats(boolean[] seats) {
        this.seats = seats;
    }

}
