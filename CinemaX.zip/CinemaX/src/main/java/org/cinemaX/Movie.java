package org.cinemaX;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
public class Movie {
    private String movieId;
    private double moviePrice;
    private String movieTitle;

    public String getMovieUrl() {
        return movieUrl;
    }

    public void setMovieUrl(String movieUrl) {
        this.movieUrl = movieUrl;
    }

    private String movieUrl;
    private String genre;
    private List<LocalDateTime> showTimes;
    private String auditoriumName;

    public Movie(String movieId, String movieTitle, String genre , String movieUrl,
                 List<LocalDateTime> showTimes,
                 String auditoriumName, double moviePrice ) {
        this.movieId = movieId;
        this.movieTitle = movieTitle;
        this.genre = genre;
        this.movieUrl = movieUrl;
        this.showTimes = showTimes;
        this.auditoriumName = auditoriumName;
        this.moviePrice = moviePrice;

    }

    public double getMoviePrice() {
        return moviePrice;
    }

    public void setMoviePrice(double moviePrice) {
        this.moviePrice = moviePrice;
    }

    public String getAuditoriumName() {
        return auditoriumName;
    }

    public void setAuditoriumName(String auditoriumName) {
        this.auditoriumName = auditoriumName;
    }

    public String getMovieId() {
        return movieId;
    }

    public void setMovieId(String movieId) {
        this.movieId = movieId;
    }

    public String getMovieTitle() {
        return movieTitle;
    }

    public void setMovieTitle(String movieTitle) {
        this.movieTitle = movieTitle;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public List<LocalDateTime> getShowTimes() {
        return showTimes;
    }

    public void setShowTimes(ArrayList<LocalDateTime> showTimes) {
        this.showTimes = showTimes;
    }
}
