package org.cinemaX;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.io.*;
import java.util.*;
import org.json.simple.*;
import org.json.simple.JSONObject;
import org.json.simple.parser.*;
public class Cinema {
    private Map<String, Auditorium> auditoriums;
    private List<Movie> movies;

    //*********************************************************************


    private static List<Movie> extractMovies(JsonNode rootNode) {
        List<Movie> movies = new ArrayList<>();

        // Assuming your JSON structure has an array of movie objects
        if (rootNode.isArray()) {
            Iterator<JsonNode> elements = rootNode.elements();

            for (int i = 0; i < rootNode.size(); i++) {
                Movie movie = new Movie(
                        rootNode.get(i).get("imdbID").asText(),
                        rootNode.get(i).get("Title").asText( ),
                        rootNode.get(i).get("Genre").asText(),
                        rootNode.get(i).get("Poster").asText(),
                        new ArrayList<LocalDateTime>(Arrays.asList(
                                LocalDateTime.parse(rootNode.get(i).get("ShowTimes").get(0).get("FirstTime").asText(), DateTimeFormatter.ISO_DATE_TIME),
                                LocalDateTime.parse(rootNode.get(i).get("ShowTimes").get(1).get("SecondTime").asText(), DateTimeFormatter.ISO_DATE_TIME),
                                LocalDateTime.parse(rootNode.get(i).get("ShowTimes").get(2).get("ThirdTime").asText(), DateTimeFormatter.ISO_DATE_TIME)

                        ))
                        ,rootNode.get(i).get("AuditoriumName").asText()
                        ,Double.parseDouble(rootNode.get(i).get("Price").asText())
                );











                movies.add(movie);
            }
        }

        return movies;
    }



    //**********************************************************************
    public Cinema() throws IOException {
        try {
            // Read JSON file
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode rootNode = objectMapper.readTree(new File("C:\\Users\\badra\\IdeaProjects\\CinemaX\\movies.json"));

            // Extract data and put each object in a list
            this.movies = extractMovies(rootNode);



        } catch (Exception exception){
            exception.printStackTrace();
        }

    }
    public List<Movie> getMovies() {
        return movies;
    }

    public void setMovies(List<Movie> movies) {
        this.movies = movies;
    }

    public Map<String, Auditorium> getAuditoriums() {
        return auditoriums;
    }

    public void setAuditoriums(Map<String, Auditorium> auditoriums) {
        this.auditoriums = auditoriums;
    }
}
