package org.cinemaX;

import java.time.LocalDateTime;
import java.util.UUID;

public class Ticketing {
    public void showAvailableMovies(Cinema cinema){
        for(Movie movie: cinema.getMovies()){
            System.out.println("Title: " + movie.getMovieTitle() + "\n" +
                    "Category: " + movie.getGenre() + "\n");
            for (LocalDateTime time : movie.getShowTimes()){
                System.out.println("Show Times: " + time.toString() + "\n");

            }
            System.out.println("Auditorium: " + cinema.getAuditoriums().get(movie.getAuditoriumName()));
            System.out.println("Available seats : " + "\n");
            boolean[] availableSeats = cinema.getAuditoriums().get(movie.getAuditoriumName()).getSeats();
            for(int i = 0; i < availableSeats.length; i++) {
                if (availableSeats[i]) {
                    System.out.println(availableSeats[i + 1] + " ");
                }
            }
        }


    }

    public void buyTicket(int movieId, LocalDateTime time, int numberOfTickets , User user,
                          double moviePrice){
        if(user.getBalance() >= moviePrice * numberOfTickets ){
            for(int i = 0; i <= numberOfTickets; i++) {
                Ticket ticket = new Ticket(moviePrice, time,
                        UUID.randomUUID().toString(),
                        movieId);
                user.addTicket(ticket);
            }
        }else{
            System.out.println("Insufficient Funds");
        }
    }
    public void refund(User user, String ticketId){
        user.removeTicket(ticketId);
    }
}
