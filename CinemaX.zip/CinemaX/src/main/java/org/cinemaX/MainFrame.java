package org.cinemaX;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

public class MainFrame {

    public static void createAndShowGUI(Cinema cinema) throws IOException, URISyntaxException {
        JFrame frame = new JFrame("CinemaX");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Create and set layout for the main panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        // Title label with a larger and stylish font
        JLabel titleLabel = new JLabel("Welcome to CinemaX" );
        Font titleFont = new Font("Arial", Font.BOLD, 24);
        titleLabel.setFont(titleFont);
        titleLabel.setHorizontalAlignment(JLabel.CENTER);
        mainPanel.add(titleLabel, BorderLayout.NORTH);





        JPanel filmGridPanel = new JPanel(new GridLayout(2, 3, 10, 10));
        mainPanel.add(filmGridPanel, BorderLayout.CENTER);



        int numberOfMovies = cinema.getMovies().size();

        for (int i = 0; i < numberOfMovies; i++) {

            URI uri = new URI(cinema.getMovies().get(i).getMovieUrl());
            BufferedImage image = ImageIO.read(uri.toURL());
            ImageIcon filmPoster = new ImageIcon(image);
            // ImageIcon filmPoster = new ImageIcon("path/to/film" + i + ".jpg");
            JButton posterButton = new JButton(filmPoster);
            posterButton.addActionListener(new FilmPosterClickListener(cinema.getMovies().get(i).getMovieTitle(), cinema.getMovies().get(i).getMovieId()));
            filmGridPanel.add(posterButton);
        }

        frame.getContentPane().add(mainPanel);
        frame.setVisible(true);
    }

    private static class FilmPosterClickListener implements ActionListener {
        private String filmTitle;
        private String filmDetails;

        public FilmPosterClickListener(String filmTitle, String filmDetails) {
            this.filmTitle = filmTitle;
            this.filmDetails = filmDetails;
        }

        @Override
        public void actionPerformed(ActionEvent e ) {
            JFrame detailsFrame = new JFrame(filmTitle + " Details");
            detailsFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            detailsFrame.setSize(800, 600);
            detailsFrame.setLayout(new BorderLayout());

            // Movie poster panel
            JPanel posterPanel = new JPanel();
            ImageIcon moviePoster = new ImageIcon("path/to/your/movie_poster.jpg");
            JLabel posterLabel = new JLabel(moviePoster);
            posterPanel.add(posterLabel);

            JPanel detailsPanel = new JPanel(new GridLayout(17, 2));
            String[] labels = {"Title:", "Year:", "Rated:", "Released:", "Runtime:", "Price:", "Genre:", "Director:",
                    "Writer:", "Actors:", "Plot:", "Language:", "Country:", "Showtimes:", "Awards:", "Auditorium Name:",
                    "Ratings:"};

            for (String label : labels) {
                JLabel titleLabel = new JLabel(label);
                JTextField textField = new JTextField();
                detailsPanel.add(titleLabel);
                detailsPanel.add(textField);
            }

            // Button to update movie details (you can replace this with actual logic)
            JButton updateButton = new JButton("Update Details");
            updateButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Add your logic to update movie details here
                }
            });

            // Adding components to the frame
            detailsFrame.add(posterPanel, BorderLayout.WEST);
            detailsFrame.add(detailsPanel, BorderLayout.CENTER);
            detailsFrame.add(updateButton, BorderLayout.SOUTH);

            detailsFrame.setVisible(true);

        }
    }
}



