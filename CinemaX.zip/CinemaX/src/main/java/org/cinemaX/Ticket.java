package org.cinemaX;

import java.time.LocalDateTime;

public class Ticket {
    private double ticketPrice;
    private LocalDateTime showTime;
    private String ticketId;

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    private int movieId;
    public String getTicketId() {
        return ticketId;
    }

    public void setTicketId(String ticketId) {
        this.ticketId = ticketId;
    }



    public Ticket(double ticketPrice, LocalDateTime showTime,
                  String ticketId, int movieId) {
        this.ticketPrice = ticketPrice;
        this.showTime = showTime;
        this.ticketId = ticketId;
        this.movieId = movieId;
    }

    public double getTicketPrice() {
        return ticketPrice;
    }

    public void setTicketPrice(double ticketPrice) {
        this.ticketPrice = ticketPrice;
    }

    public LocalDateTime getShowTime() {
        return showTime;
    }

    public void setShowTime(LocalDateTime showTime) {
        this.showTime = showTime;
    }
}
