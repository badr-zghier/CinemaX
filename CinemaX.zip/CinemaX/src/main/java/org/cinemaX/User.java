package org.cinemaX;

import java.util.List;

public class User {
    private String userName;
    private List<Ticket> tickets;
    private double balance;

    public User(String userName, List<Ticket> tickets, double balance) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public List<Ticket> getTickets() {
        return tickets;
    }

    public void setTickets(List<Ticket> tickets) {
        this.tickets = tickets;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
    public void addTicket(Ticket ticket){
        this.tickets.add(ticket);
    }

    public void removeTicket(String ticketId){
        try {
            this.tickets.removeIf(ticket -> ticket.getTicketId().equals(ticketId));
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
