package org.cinemaX;

import javax.swing.*;
import java.io.IOException;
import java.net.URISyntaxException;

public class Main {

    public static void main(String[] args) throws IOException {
        Cinema cinema = new Cinema();
        SwingUtilities.invokeLater(() -> {
            try {
                MainFrame.createAndShowGUI(cinema);
            } catch (IOException e) {
                throw new RuntimeException(e);
            } catch (URISyntaxException e) {
                throw new RuntimeException(e);
            }
        });
    }

}
